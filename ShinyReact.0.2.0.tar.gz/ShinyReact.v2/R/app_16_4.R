#library(shiny)
#install.packages("DT")
#library(DT)
#library(dplyr)
#library(tibble)
#library(base)
#library(fitdistrplus)
#install.packages("formattable")
#library(formattable)
# Set the CRAN mirror
options(repos = c(CRAN = "https://cran.rstudio.com/"))
# List of required packages
required_packages <- c("shiny", "DT", "dplyr", "tibble", "base", "fitdistrplus", "formattable", "readxl")

# Check if each package is installed and load it if needed
for (package in required_packages) {
  if (!requireNamespace(package, quietly = TRUE)) {
    install.packages(package)
  }
  library(package, character.only = TRUE)
}

# Your code continues here
# ...

# For example, you can use shiny functions, DT, dplyr, tibble, base, fitdistrplus, and formattable in your subsequent code.


ui <- navbarPage(
  h2("Shiny React test version 2.0"),
  tabPanel("Calculator",
           sidebarLayout(
             sidebarPanel(
               fileInput("upload", NULL, buttonLabel = "Upload...", multiple = TRUE),
               h2("Input values"),
               numericInput("num1", "Quant value of known contributor:", 0),
               numericInput("num2", "Quant value of unknown contributor:", 0),
               selectInput("expt_num", "BN library and experiment:",
                           choices = c("2", "3.0", "3.1", "3.2"),
                           selected = "2"),
               numericInput("An_Thresh", "Input analytical threshold in RFU:", 50),
               actionButton("click", "Run"),
               h2("Instructions"),
               p("1) Upload all data and image files from the folder"),
               p("2) Input quant values in nanograms for known and unknown contributors. If there is no unknown contributor, input 0"),
               p("3) Select BN (Bayes Net) and experiment you want to test"),
               p("4) Input analytical threshold in RFU"),
               p("5) Click 'Run' to calculate LR and bootstrapped percentiles")
             ),
             mainPanel(
               fluidPage(
                 fluidRow(
                   h2("Results Output"),
                   column(11, offset = 1, DTOutput("LR_out_table"))
                 ),
                 fluidRow(
                   h2("Bootstrapped LR Results (Percentiles)"),
                   class = "mt-20", # Add margin-top of 4 units (adjust as needed)
                   column(11, offset = 1, DTOutput("bootstrap_out_table"),
                          verbatimTextOutput("failed_boots"),
                          verbatimTextOutput("checksums_Hp"),
                          h2("Definitions"),      
                          tags$p(HTML("<b>BN</b>: Bayes Net and experiment number e.g. 3.1 means BN=3 and experiment 1")),
                          tags$p(HTML("<b>Known.Quant</b>: DNA Quantity (ng) of known contributor")),
                          tags$p(HTML("<b>Unknown.Quant</b>: DNA Quantity (ng) of unknown contributor(s)")),
                          tags$p(HTML("<b>LRTog</b>: Likelihood Ratio calculated if there is an unknown contributor(s)")),
                          tags$p(HTML("<b>LRPOI</b>: Likelihood Ratio calculated if there is no unknown contributor(s)")),
                          tags$p(HTML("<b>Qual.LR</b>: Qualitative likelihood Ratio calculated without a consideration of DNA quantity")),
                          tags$p(HTML("<b>Sample.Size</b>: Number of samples in the set analysed to provide the results")),
                          tags$p(HTML("<b>Failed bootstraps</b>: Number of bootstraps that failed to converge (out of 1000)")),
                          tags$p(HTML("<b>Check Pr sums</b>: A quality check to make sure probabilties under Hp and Hd (right-hand table below)sum to one)"))
                          ),
                   
                   fluidRow(
                    column(6,offset=0, DTOutput("table_Pr")),
                    column(6,offset=0, DTOutput("table_Hd"))
                   ),
                   fluidRow(
                     column(12,offset=0, DTOutput("table_Hp")),
                     h2("Table notes"), 
                     p("A list of probabilties used to calculate the LR results is provided in the tables above. Probabilities in left 
                       hand table are t: Pr of recovery from the last handler of screwdriver; s: Pr of recovery from the first handler
                       of screwdriver for expt. 2 and secondary transfer via social contact for expt 3; t': Pr of recovery from an 
                       unknown contributor under Hd; b: probability of background DNA recovery. These probabilities can be plugged 
                       into a standard Bayesian Network like Hugin which will provide the same answers listed in the Results Ouput above"),
                     p("Probabilities are expectations of finding a listed category, given DNA quantities that are greater than that provided in the input values:
                       (Prs are based on 1-cdf values)")
                     
                     
                     
                   )
                 )
               )
             )
           )
  ),     
           
           
  tabPanel("Probability and Regression",
           fluidPage(
             #fileInput("upload", NULL, buttonLabel = "Upload...", multiple = TRUE),
             fluidRow(
               h2("Regression of average RFU vs DNA quantity(ng)", style = "text-align: center;"),
               br(),
               column(8, offset = 4, imageOutput("regression_plot"), style = "margin-bottom: 250px;")
             ),
             fluidRow(
               h2("Probability (1-cdf) plot of handler and background for experiment 1", style = "text-align: center;"),
               br(),
               column(8, offset = 4, imageOutput("expt1_probability_plot")),
               style = "margin-bottom: 220px;"  # Adjust the margin-bottom value as needed
             ),
             fluidRow(
               h2("Probability (1-cdf) plots of first and second handlers and background for experiments 2,3", style = "text-align: center;"),
               br(),
               column(9, offset = 3, imageOutput("probability_plot"))
             )
           )
  
  ),
  tabPanel("Experiment 2 Results",
           fluidRow(
             column(
               width = 6,
              # fileInput("upload_pr", NULL, buttonLabel = "Upload...", multiple = TRUE),
               h2("Experiment 2 LR results"),
               p("The LR results are tabulated according to recovery of POI DNA ng.top row in bold type"),
               p("Unknown.Q is the DNA quantity of unknown contributors"),
               p("The first row (where DNA quantity of unknowns = 0), gives LR of 'POI only' recovered"),
               br(),
               h4("Quants(ng) POI", style = "text-align: center;")
             )
             ),

           fluidRow(
             column(
               width = 12,
              div(style = "overflow-x: auto;",
               tableOutput("excel_data")
             )
           ),
           fluidRow(
             column(
               width = 5,
               imageOutput("expt2_data")
             ),
             column(
               width = 5,
               offset=2,
               h4("Outline of Case Circumstances"),
               p("A tool (screwdriver) is used to force open a door in a burglary. 
                 The tool has been left at the crime scene, and there is no doubt
                 that it was used by the perpetrator."),
               p("Suspect X (known individual) is arrested and accused of the crime.
                 He states that it is his tool, but that it had been recently stolen,
                 and that he did not force the door in the burglary."),
               h4("Findings"),
               p("The DNA aligns with X at sub-source level. Here we do not consider
                 the LR at this level. There may or may not be DNA from an unknown
                 contributor(s) present."),
               h4("Propositions"),
               p("P1: Either the suspect (known individual) handled the tool at the crime-scene."),
               p("P2: Or an unknown person handled the tool at the crime scene."),
               h4("Comment"),
               p("The LR is calculated from the probability of DNA recovery from first
                 and second handlers of the screwdriver under P1 and P2 respectively")
               
             )
             
             
           )
           )
           ),
  
  tabPanel("Experiment 3 (0h) Results",
           fluidRow(
             column(
               width = 6,
             # fileInput("upload_expt3_0", NULL, buttonLabel = "Upload...", multiple = TRUE),
               h2("Experiment 3.0 LR results"),
               p("The LR results are tabulated according to recovery of POI DNA ng.top row in bold type"),
               p("Unknown.Q is the DNA quantity of unknown contributors"),
               p("The first row (where DNA quantity of unknowns = 0), gives LR of 'POI only' recovered"),
               br(),
               h4("Quants(ng) POI", style = "text-align: center;")
             )
           ),
           fluidRow(
             column(
               width = 12,
               div(style = "overflow-x: auto;",
                   tableOutput("excel_data_expt3_0")
               )
             ),
             fluidRow(
               column(
                 width = 5,
                 imageOutput("expt3_0_image")
               ),
               
               column(
                 width = 5,
                 offset=2,
                 h4("Outline of Case Circumstances"),
                 p("A tool (screwdriver) is used to force open a door in a burglary. 
                 The tool has been left at the crime scene, and there is no doubt
                 that it was used by the perpetrator."),
                 p("Suspect X (known individual) is arrested and accused of the crime.
                 He denies the offence. He states that he has never seen the tool and does
                 not own it. At the time of the offence he says he was at home watching TV
                 (although the alibi cannot be corroborated)."),
               h4("Findings"),
               p("The DNA aligns with X at sub-source level. Here we do not consider
                   the LR at this level. There may or may not be DNA from an unknown
                   contributor(s) present."),
               h4("Propositions"),
               p("P1: Either the suspect (known individual) handled the tool at the crime-scene."),
               p("P2: Or an unknown person handled the tool at the crime scene."),
               h4("Comment"),
               p("The suspect has never knowingly handled the screwdriver under P2;
               therefore the presence of his DNA is attributed to indirect transfer.
               The LR is calculated from the probability of DNA recovery from the handler
               of the screwdriver and the person he had social contact with (handshake) under P1 and P2 respectively. Under the conditions tested,
                 it is assumed that the perpetrator committed the offence immediately following social contact. The
                 probability of indirect trasnfer is maximised, and in the absence of a clear time-line, this will always benefit 
                 the defence proposition P2")
             )
            )
           )

  ),
  
  tabPanel("Experiment 3 (1h) Results",
           fluidRow(
             column(
               width = 6,
              # fileInput("upload_expt3_1", NULL, buttonLabel = "Upload...", multiple = TRUE),
               h2("Experiment 3.1 LR results"),
               p("The LR results are tabulated according to recovery of POI DNA ng.top row in bold type"),
               p("Unknown.Q is the DNA quantity of unknown contributors"),
               p("The first row (where DNA quantity of unknowns = 0), gives LR of 'POI only' recovered"),
               br(),
               h4("Quants(ng) POI", style = "text-align: center;")
             )
           ),
           fluidRow(
             column(
               width = 12,
               div(style = "overflow-x: auto;",
                   tableOutput("excel_data_expt3_1")
               )
             ),
             fluidRow(
               column(
                 width = 5,
                 imageOutput("expt3_1_image")
               ),
                 column(
                   width = 5,
                   offset=2,
                   h4("Outline of Case Circumstances"),
                   p("A tool (screwdriver) is used to force open a door in a burglary. 
                 The tool has been left at the crime scene, and there is no doubt
                 that it was used by the perpetrator."),
                   p("Suspect X (known individual) is arrested and accused of the crime.
                 He denies the offence. He states that he has never seen the tool and does
                 not own it. At the time of the offence he says he was at home watching TV
                 (although the alibi cannot be corroborated)."),
                   h4("Findings"),
                   p("The DNA aligns with X at sub-source level. Here we do not consider
                   the LR at this level. There may or may not be DNA from an unknown
                   contributor(s) present."),
                   h4("Propositions"),
                   p("P1: Either the suspect (known individual) handled the tool at the crime-scene."),
                   p("P2: Or an unknown person handled the tool at the crime scene."),
                   h4("Comment"),
                   p("The suspect has never knowingly handled the screwdriver under P2;
               therefore the presence of his DNA is attributed to indirect transfer.
               The LR is calculated from the probability of DNA recovery from the handler
               of the screwdriver and the person he had social contact with (handshake) under P1 and P2 respectively. Under the conditions tested,
                 it is assumed that the perpetrator committed the offence one hour following social contact.")
                 
                 
                 
               )
             )
           )
  ),
  
  tabPanel("Experiment 3 (2h) Results",
           fluidRow(
             column(
               width = 6,
             #  fileInput("upload_expt3_2", NULL, buttonLabel = "Upload...", multiple = TRUE),
               h2("Experiment 3.2 LR results"),
               p("The LR results are tabulated according to recovery of POI DNA ng.top row in bold type"),
               p("Unknown.Q is the DNA quantity of unknown contributors"),
               p("The first row (where DNA quantity of unknowns = 0), gives LR of 'POI only' recovered"),
               br(),
               h4("Quants(ng) POI", style = "text-align: center;")
             )
           ),
           fluidRow(
             column(
               width = 12,
               div(style = "overflow-x: auto;",
                   tableOutput("excel_data_expt3_2")
               )
             ),
             fluidRow(
               column(
                 width = 5,
                 imageOutput("expt3_2_image")
               ),
            
               column(
                 width = 5,
                 offset=2,
                 h4("Outline of Case Circumstances"),
                 p("A tool (screwdriver) is used to force open a door in a burglary. 
                 The tool has been left at the crime scene, and there is no doubt
                 that it was used by the perpetrator."),
                 p("Suspect X (known individual) is arrested and accused of the crime.
                 He denies the offence. He states that he has never seen the tool and does
                 not own it. At the time of the offence he says he was at home watching TV
                 (although the alibi cannot be corroborated)."),
                 h4("Findings"),
                 p("The DNA aligns with X at sub-source level. Here we do not consider
                   the LR at this level. There may or may not be DNA from an unknown
                   contributor(s) present."),
                 h4("Propositions"),
                 p("P1: Either the suspect (known individual) handled the tool at the crime-scene."),
                 p("P2: Or an unknown person handled the tool at the crime scene."),
                 h4("Comment"),
                 p("The suspect has never knowingly handled the screwdriver under P2;
               therefore the presence of his DNA is attributed to indirect transfer.
               The LR is calculated from the probability of DNA recovery from the handler
               of the screwdriver and the person he had social contact with (handshake) under P1 and P2 respectively. Under the conditions tested,
                 it is assumed that the perpetrator committed the offence two hours following social contact.")            
               )
               
                )
           )
  )
)
server <- function(input, output, session) {
  source("BNprog_Fun_16_4.R")
  uploaded_files <- reactive({
    req(input$upload)
    input$upload
  })
  ###########################################
  #Pie chart function for expt2
  # Function to calculate values using an external R script
  #NumPOI=NumPOI, DenPOI=DenPOI, LRPOI=LRPOI, NumTog=NumTog, DenTog=DenTog,LRTog=LRTog,NumU=NumU,DenU=DenU,NoDNA_Num=NoDNA_Num,NoDNA_Den=NoDNA_Den
# calculateValues <- function(LR_value) {
    # Replace this with the code that calculates Value 1 and Value 2
    #####Pie Chart numerator values - POI, Tog, U only and no DNA
#    NumPOI <-LR_value$LR_Test_results$NumPOI  
#    NumTog <-LR_value$LR_Test_results$NumTog
#    NumU<-LR_value$LR_Test_results$NumU
#    NoDNA_Num<-LR_value$LR_Test_results$NoDNA_Num
#    return(list(NumPOI = NumPOI, NumTog = NumTog,NumU=NumU,NoDNA_Num=NoDNA_Num)) 
#  } 
  
 

  
  
  ################
 # data <- reactive({
  #  if ("Mainz.xlsx" %in% uploaded_files()$name) {
  #    selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Mainz.xlsx"]
  #    df_data <- readxl::read_excel(selected_file,sheet = "data", col_names = TRUE)
  #    df_data<-as.data.frame(df_data) # Convert back to data frame
  #  } 
 # })
 ###################################### 
  data <- reactive({
    matching_files <- grepl("lab.*\\.xlsx", uploaded_files()$name, ignore.case = TRUE)
    
    if (any(matching_files)) {
      selected_file <- uploaded_files()$datapath[matching_files]
      df_data <- readxl::read_excel(selected_file, sheet = "data", col_names = TRUE)
      df_data <- as.data.frame(df_data) # Convert back to data frame
      return(df_data)
    } else {
      # Return an empty data frame or NULL if no matching file is found
      return(data.frame())
      # or return(NULL)
    }
  }) 
  
  
  
  
############################
  
  # Reactive value to store generated value that is available to other observeEvents
  gen_LR_Value <- reactiveVal(NULL)
  observeEvent(input$click, {
    LR_value <- statistic_function(data(), input$expt_num, input$num1, input$num2, input$An_Thresh)
    gen_LR_Value(LR_value$LR_Test_results)
  })
  
  # Render the output for the LR
 # observeEvent(input$click, { output$LR_out <- renderText({ 
  #  paste("The LR value for known", input$num1, "and unknown", input$num2, "is", statistic_function(data(),input$expt_num,input$num1,input$num2,input$An_Thresh)) 
    
 # }) 
 # })
  
  observeEvent(input$click, {
    
    LR_value <- statistic_function(data(), input$expt_num, input$num1, input$num2, input$An_Thresh)
    # Extract specific values or columns from the LR_value object
    LR_value_LRTog <- LR_value$LR_Test_results$LRTog
    LR_value_LRPOI <- LR_value$LR_Test_results$LRPOI
    if (input$num2==0){
      LR_value_LRTog <- NA
     BNT<- LR_value$BNTresults$LRPOI##threshold LR value without peak height
    }else{
      LR_value_LRPOI <- NA
      BNT<- LR_value$BNTresults$LRTog##threshold LR value without peak height
    }
    n <- nrow(LR_value$data) # Number of rows in the data frame (sample size)
    # Combine extracted values into a data frame
    # Combine extracted values into a data frame
    LR_table <- data.frame(BN = input$expt_num, 
                           Known.Quant = input$num1, 
                           Unknown.Quant = input$num2,
                           LRTog = LR_value_LRTog, 
                           LRPOI = LR_value_LRPOI,
                           Qual.LR=BNT,
                           Sample.Size = n)
    
    # Format columns in LR_table to scientific notation with one decimal
    LR_table$LRTog <- format(LR_table$LRTog, scientific = TRUE, digits = 2)
    LR_table$LRPOI <- format(LR_table$LRPOI, scientific = TRUE, digits = 2)
    LR_table$Qual.LR <- format(LR_table$Qual.LR, scientific = TRUE, digits = 2)
    # Change row names
    rownames(LR_table) <- c("Results")
    output$LR_out_table <- renderDT({
      datatable(
        LR_table,
        options = list(
          searching = FALSE, # Remove the search box
          lengthChange = FALSE, # Hide the show 10 entries button
          info = FALSE, # Hide the information element
          paging = FALSE, # Hide the pagination element
          scrollX = TRUE,
          columnDefs = list(list(width = '150px', targets = "_all")), # Adjust the column width
          initComplete = JS(
            "function(settings, json) {",
            "$('.dataTables_scrollHeadInner th:eq(2)').css('padding-right', '10px');", # Adjust the padding of the LRPOI column header
            "}"
        )
        )
      )%>% 
        formatStyle(c('BN', 'Known.Quant', 'Unknown.Quant','LRTog','LRPOI','Sample.Size'), textAlign = 'center', target='cell') # Align columns to the center
  })
})
########################################################################################################  
  ###Do bar chart here for Hp
  output$table_Pr <- DT::renderDataTable({
    req(input$click)  # Wait for the button to be pressed
    
    # Get the reactive value
    gen_LR_Value <- gen_LR_Value()
    # Create the data frame
    dataBar <- data.frame(
      Category = c("Last H (t)", "First H (s)", "Unknown (t')", "Background (b)"),
      Probability = c(gen_LR_Value$AsT, gen_LR_Value$SecT, gen_LR_Value$AsTU, gen_LR_Value$Bac)
    )

    # Format the values to scientific notation with two digits
    dataBar$Probability <- format(dataBar$Probability, scientific = TRUE, digits=2)
    # Return the data frame as a DT table
    DT::datatable(dataBar, options = list(
      searching = FALSE,  # Remove the search box
      lengthChange = FALSE, # Hide the show 10 entries button
      info = FALSE, # Hide the information element
      paging = FALSE, # Hide the pagination element
      scrollX = TRUE     
    )) 
  })
  
  #######################################################################################################
  output$table_Hd <- DT::renderDataTable({
    req(input$click)  # Wait for the button to be pressed
    
    # Get the reactive value
    gen_LR_Value <- gen_LR_Value()
    
    # Create the data frame
    dataBar <- data.frame(
      Category = c("POI only", "POI+Unknown", "Unknown only", "No DNA"),
      Hp = c(gen_LR_Value$NumPOI, gen_LR_Value$NumTog, gen_LR_Value$NumU, gen_LR_Value$NoDNA_Num),
      Hd = c(gen_LR_Value$DenPOI, gen_LR_Value$DenTog, gen_LR_Value$DenU, gen_LR_Value$NoDNA_Den)
    )

    # Format the values to scientific notation with three digits
    dataBar$Hp <- format(dataBar$Hp, scientific = TRUE, digits=2)
    dataBar$Hd <- format(dataBar$Hd, scientific = TRUE, digits=2)
    # Return the data frame as a DT table
    DT::datatable(dataBar, options = list(
                                   searching = FALSE,  # Remove the search box
                                   lengthChange = FALSE, # Hide the show 10 entries button
                                   info = FALSE, # Hide the information element
                                   paging = FALSE, # Hide the pagination element
                                   scrollX = TRUE     
                                          )) 
  })
  
   
  #######################################################################################################
  ###Do Bootstrapping using individual column bootstrap2 function
  
  observeEvent(input$click, {
   LR_value <- statistic_function(data(), input$expt_num, input$num1, input$num2, input$An_Thresh)
    num_samples <- 1000  # Number of bootstrap iterations
    Expt <- input$expt_num
    y_known_quant <- input$num1
    y_unknown_quant <- input$num2
    AT <- input$An_Thresh
    bootstrap_results2 <- bootstrap_and_calculate2(LR_value$data, num_samples, Expt,y_known_quant,y_unknown_quant,AT)
    # Create a data frame from the list

     if (y_unknown_quant==0){
      boot_res <- bootstrap_results2$DNA_POIOnlyr
 }else{
     boot_res <- bootstrap_results2$DNA_Togyr
      }
    Quantiles<-data.frame(boot_res) # Convert back to data frame
    
    # Transpose the data frame
    transposed_df <- t(Quantiles)
    # Change row names
    rownames(transposed_df) <- c("Percentiles")
    
    
    # Format columns in LR_table to scientific notation with one decimal
    transposed_df <- format(transposed_df, scientific = TRUE, digits = 2)
    #LR_table$LRPOI <- format(LR_table$LRPOI, scientific = TRUE, digits = 2)
    
    #add text to show number of failed bootstraps
    output$failed_boots <- renderText({
      paste("Failed bootstraps =", bootstrap_results2$Failed)
    })
      #add text to show checksums Hp and Hd
      output$checksums_Hp <- renderText({
        paste("Check Pr sums Hp =", LR_value$LR_Test_results$PrSumHp,
              ";;;  Check Pr sums Hd =", LR_value$LR_Test_results$PrSumHd)
    })
    output$bootstrap_out_table <- renderDT({
      datatable(
        transposed_df,
        options = list(
          searching = FALSE, # Remove the search box
          lengthChange = FALSE, # Hide the show 10 entries button
          info = FALSE, # Hide the information element
          paging = FALSE, # Hide the pagination element
          scrollX = TRUE,
          columnDefs = list(list(width = '150px', targets = "_all")), # Adjust the column width
          initComplete = JS(
            "function(settings, json) {",
            "$('.dataTables_scrollHeadInner th:eq(2)').css('padding-right', '10px');", # Adjust the padding of the LRPOI column header
            "}"
          )
        )
      )%>% 
        formatStyle(c('2.5%', '5%', '25%','50%','75%','95%','97.5%'), textAlign = 'center', target='cell') # Align columns to the center
    })
  
  
  })
  
  #######################################################################################################
  #######################################################################################################

    
    
    
    
  #####################################################################################################
  ##################################################################################################
  #expt2 .png file
  observe({
    if ("Exp_2_plot.png" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Exp_2_plot.png"]
      output$expt2_data <- renderImage({
        list(src = selected_file, alt = "Uploaded Image")
      }, deleteFile = FALSE)
    }
  })
  
  #library(dplyr)
  ###Expt 2 excel file
  observe({
    if ("Results_Exp_2.xlsx" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Results_Exp_2.xlsx"]
      df <- readxl::read_excel(selected_file)
      
      # Data processing - excluding the first column and applying formatting
      df_formatted <- df[, -1]  # Exclude the first column
      df_formatted <- apply(df_formatted, 2, function(x) formatC(x, format = "e", digits = 1))  # Apply formatting
      
      # Extract the first column for row names
      first_column <- df[, 1]
      
      #Add column back into the dataframe
      df_formatted <- cbind(first_column, df_formatted)
      
      #change name of first column to Unknown.Q
      colnames(df_formatted)[1] <- "Unknown.Q"
      
      #centre column 1
      df_formatted$Unknown.Q <- format(df_formatted$Unknown.Q, scientific = FALSE, digits = 3)
      
      
      # Assign the row names to the formatted data frame
     #row.names(df_formatted) <- first_column$z
      
      # Output the table with row names
      output$excel_data <- renderTable({
        df_formatted
      }, rownames = TRUE)
      
    }
  })
  
  observe({
    if ("pr_plot_Ex1.png" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "pr_plot_Ex1.png"]
      output$expt1_probability_plot <- renderImage({
        list(src = selected_file, alt = "Uploaded Image",width = 5.5 * 96, height = 5 * 96)
      }, deleteFile = FALSE)
    }
  })
  
  observe({
    if ("combined_pr_plot.png" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "combined_pr_plot.png"]
      output$probability_plot <- renderImage({
        list(src = selected_file, alt = "Uploaded Image")
      }, deleteFile = FALSE)
    }
  })
  
  # Display "reg_plot_Ex1.png" in the Probability and Regression tab
  observe({
    if ("reg_plot_Ex1.png" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "reg_plot_Ex1.png"]
      output$regression_plot <- renderImage({
        list(src = selected_file, alt = "Uploaded Image", width = 6 * 96, height = 6 * 96)
      }, deleteFile = FALSE)
    }
  })
  
#EXP 3.0xls file
  observe({
    if ("Results_Exp_3.0.xlsx" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Results_Exp_3.0.xlsx"]
      df <- readxl::read_excel(selected_file)
      # Data processing - excluding the first column and applying formatting
      df_formatted <- df[, -1]  # Exclude the first column
      df_formatted <- apply(df_formatted, 2, function(x) formatC(x, format = "e", digits = 1))  # Apply formatting
      
      # Extract the first column for row names
      first_column <- df[, 1]
      
      #Add column back into the dataframe
      df_formatted <- cbind(first_column, df_formatted)
      
      #change name of first column to Unknown.Q
      colnames(df_formatted)[1] <- "Unknown.Q"
      
      #centre column 1
      df_formatted$Unknown.Q <- format(df_formatted$Unknown.Q, scientific = FALSE, digits = 3)
      
      
      # Assign the row names to the formatted data frame
      #row.names(df_formatted) <- first_column$z
      
      # Output the table with row names
      output$excel_data_expt3_0 <- renderTable({
        df_formatted
      }, rownames = TRUE)
      
    }
  })
  
  
  observe({
    if ("Exp_3.0_plot.png" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Exp_3.0_plot.png"]
      output$expt3_0_image <- renderImage({
        list(src = selected_file, alt = "Uploaded Image")
      }, deleteFile = FALSE)
    }
  })
  #Exp3_1 results are output here
  observe({
    if ("Results_Exp_3.1.xlsx" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Results_Exp_3.1.xlsx"]
      df <- readxl::read_excel(selected_file)
      # Data processing - excluding the first column and applying formatting
      df_formatted <- df[, -1]  # Exclude the first column
      df_formatted <- apply(df_formatted, 2, function(x) formatC(x, format = "e", digits = 1))  # Apply formatting
      
      # Extract the first column for row names
      first_column <- df[, 1]
      
      #Add column back into the dataframe
      df_formatted <- cbind(first_column, df_formatted)
      
      #change name of first column to Unknown.Q
      colnames(df_formatted)[1] <- "Unknown.Q"
      
      #centre column 1
      df_formatted$Unknown.Q <- format(df_formatted$Unknown.Q, scientific = FALSE, digits = 3)
      
      
      # Assign the row names to the formatted data frame
      #row.names(df_formatted) <- first_column$z
      
      # Output the table with row names
      output$excel_data_expt3_1 <- renderTable({
        df_formatted
      }, rownames = TRUE)
      
    }
  })
  
  observe({
    if ("Exp_3.1_plot.png" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Exp_3.1_plot.png"]
      output$expt3_1_image <- renderImage({
        list(src = selected_file, alt = "Uploaded Image")
      }, deleteFile = FALSE)
    }
  })
  
  #Exp3_2 results are output here
  observe({
    if ("Results_Exp_3.2.xlsx" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Results_Exp_3.2.xlsx"]
      df <- readxl::read_excel(selected_file)
      # Data processing - excluding the first column and applying formatting
      df_formatted <- df[, -1]  # Exclude the first column
      df_formatted <- apply(df_formatted, 2, function(x) formatC(x, format = "e", digits = 1))  # Apply formatting
      
      # Extract the first column for row names
      first_column <- df[, 1]
      
      #Add column back into the dataframe
      df_formatted <- cbind(first_column, df_formatted)
      
      #change name of first column to Unknown.Q
      colnames(df_formatted)[1] <- "Unknown.Q"
      
      #centre column 1
      df_formatted$Unknown.Q <- format(df_formatted$Unknown.Q, scientific = FALSE, digits = 3)
      
      
      # Assign the row names to the formatted data frame
      #row.names(df_formatted) <- first_column$z
      
      # Output the table with row names
      output$excel_data_expt3_2 <- renderTable({
        df_formatted
      }, rownames = TRUE)
      
    }
  })
  ##Exp3_2 results plot
  observe({
    if ("Exp_3.2_plot.png" %in% uploaded_files()$name) {
      selected_file <- uploaded_files()$datapath[uploaded_files()$name == "Exp_3.2_plot.png"]
      output$expt3_2_image <- renderImage({
        list(src = selected_file, alt = "Uploaded Image")
      }, deleteFile = FALSE)
    }
  })
  
  
}

shinyApp(ui = ui, server = server)
